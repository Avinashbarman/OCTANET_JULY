<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <script>
        function valid()
        {
            

            var b=document.getElementById("t1").value
            if(isNaN(b)==true)
            {
                document.getElementById("x").innerHTML=" Mobile no. must be a Number";
                document.getElementById("x").style.color="red";
            }
            else if(b.length!=10){
                document.getElementById("x").innerHTML=" Mobile no. must be 10 digit";
                document.getElementById("x").style.color="red";
            }
            else{
                document.getElementById("x").innerHTML="valid";
                document.getElementById("x").style.color="green";
            }

            var b=document.getElementById("t3").value
            if(isNaN(b)==true)
            {
                document.getElementById("y").innerHTML=" Adhar no. must be a Number";
                document.getElementById("y").style.color="red";
            }
            else if(b.length!=10){
                document.getElementById("y").innerHTML=" Adhar no. must be 12 digit";
                document.getElementById("y").style.color="red";
            }
            else{
                document.getElementById("y").innerHTML="valid";
                document.getElementById("y").style.color="green";
            }

            var p=document.getElementById("t2").value
            var u=0, l=0, d=0, s=0;
            for(i=0; i<p.length; i=i+1){
                var c=p.charCodeAt(i);
                
                    if(c>=65&&c<=90)
                    {
                        u=u+1;
                        
                    }
                    
                    else if(c>= 97&& c<=122)
                    {
                        l=l+1;

                    }
                    else if(c>= 48&& c<=57)
                    {
                        d=d+1;
                    }
                    else{
                        s=s+1;
                    }
                    
                
            }
            console.log(u+" "+l+" "+d+" "+s);
           if(u==0||l==0||d==0||s==0){
            document.getElementById("w").innerHTML="Weak Password"
            document.getElementById("w").style.color="red";
            
           }
           else{
            document.getElementById("w").innerHTML="Strong Password"
            document.getElementById("w").style.color="green";

           }
        }
    </script>
    <link href="register.css" rel="stylesheet">
           <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

</head>
<body>
    <form action="farmer registration2.php" method="POST">
    <div class = "register-form">
	 <header class="header d-flex flex-row">
		<div class="header_content d-flex flex-row align-items-center">
			<!-- Logo -->
			<div class="logo_container">
				<div class="logo">
					<img img src="74846d6c-4508-4e94-9b80-c929eaadd360.jpeg" alt="" width = "90px" height = "78px">
					<span>Agrohub</span>
				</div>
			</div>
			<div class="header_side d-flex flex-row justify-content-center align-items-center"></div>
		
		<div class="hamburger_container">
			<i class="fas fa-bars trans_200"></i>
		</div>
			</header>
			
        <h3>Farmer Registration</h3><br><br>
        
            <h6 align = "left">Full Name</h6>
			
			<input type="text"  name="name" placeholder="Enter Your Name" ><br><br>
            <h6 align = "left">Phone No</h6>
		   
			<input type="text" id="t1" name="phone" placeholder="Phone Number" onblur="valid()"><span id="x"></span><br><br>
           <h6 align = "left"> Email id</h6>
			
			<input type="text" name="email" placeholder="E Mail ID"><br><br>
           <h6 align = "left"> Parmanent Address</h6>
			
			<input type="text" name="address" placeholder="Address"><br><br>
           <h6 align = "left"> Adhar no.</h6>
			
			<input type="text" name="adhar" id="t3" placeholder="Adhar no." onblur="valid()"><span id="y"></span><br><br>
            <h6 align = "left">Password</h6>
			
			<input type="password" name="pass" id="t2" placeholder="Password" onblur="valid()"><span id="w"></span><br><br>
       
	   <div class = "btn">
        <button class="btn btn-danger">Register</button>
		</div>
        <!-- <button><a href="farmer login.php">login</a></button> -->
        <!-- <button><a href="farmer login.php">login</a></button> -->
    </form>
</body>
</html>