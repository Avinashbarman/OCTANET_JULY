<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buyer Registration</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>

    <!-- <script>
        $(function()
        {
            $("form[name='studentregistration']").validate({
                rules:{
                    roll : {
                        required: true,
                        minlength: 5
                    },
                    name : "required",
                    branch : "required",
                    sem : "required",
                    mob : {
                        requierd : true,
                        minlength : 10
                    } ,
                    secque:"required",
                    secanss:"required",
                    pass: {
                         required: true,
                          minlength: 5
        }

                },
                messages:
                {
                    roll : {
                        required : "Please provide a password",
                        minlength : "Your Roll no must be at least 5 characters long"
                    },  
                    name : "Please enter your Name",
                    branch : "Please select your Branch",
                    sem : "Please select your semester",
                    mob : {
                        requierd : "Please provide a mobile no",
                        minlength : "Mobile no. must be 10 digit"
                    } ,
                    secque : "Please enter your security Question",
                    secanss : "Please enter your security Answer",
                    pass : {
                         required : "Please provide a password",
                        minlength : "Your password must be at least 5 characters long"
        },
                }
            }
            )
        })
    </script> -->
    <link href="register.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

</head>
<body>
    <form  action="buyerregistration2.php" method="POST">
        
    <div class = "register-form">
	 <header class="header d-flex flex-row">
		<div class="header_content d-flex flex-row align-items-center">
			<!-- Logo -->
			<div class="logo_container">
				<div class="logo">
					<img img src="74846d6c-4508-4e94-9b80-c929eaadd360.jpeg" alt="" width = "90px" height = "78px">
					<span>Agrohub</span>
				</div>
			</div>
			<div class="header_side d-flex flex-row justify-content-center align-items-center"></div>
		
		<div class="hamburger_container">
			<i class="fas fa-bars trans_200"></i>
		</div>
		</div>
			</header>
    <form  action="buyerregistration2.php" method="POST">
        
    <h3>Buyer Registration</h3>
     <table>
        <tr><td>Full Name</td><td><input type="text" name="fname" required></td></tr>
        <tr><td>Phone no</td><td><input type="text" name="mob" required></td></tr>
        <tr><td>Email id</td><td><input type="text" name="email" required></td></tr>
        <tr><td>Present Address</td><td><input type="text" name="padd" required></td></tr>
        <tr><td>Company Name</td><td><input type="text" name="comp" required></td></tr>
        <tr><td>PAN no</td><td><input type="text" name="pan" required></td></tr>
        <tr><td>Type</td><td><select name="type" required>
            <option value=""></option>
            <option value="crop">crop</option>
            <option value="vegetable">Vegetable</option>
            <option value="fruits">Fruits</option>
        </select></td></tr><br>
        <tr><td>Password</td><td><input type="password" name="pass" required></td></tr>
		

     </table>
	 <div class = "btn">
    <button class="btn btn-danger">Register</button>
	</div>

    </form>
    
</body>
</html>