<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Farmer Login</title>
    <script>
        function sign()
        {
         window.location = 'farmerregistration.php';
        }
    </script>
    	<style>
      .logg{
             border-radius:30px;
	     margin-top:150px;
	     margin-left:350px;
	     margin-right:350px;
	     margin-bottom:200px;
      }
             
	     
          
		  
		  body{
            background-image:url("https://i.pinimg.com/originals/b5/58/c1/b558c15b7510220c52c9ed7258683490.jpg");
			background-size:cover;
			
	    
	  }
      
      
   </style>
       <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

</head>
<body>
    <form method="POST">
    <div class = "container" >
		<div class = "logg">
			<center>
				<form method="POST">
					<center><h1>Farmer Log In</h1></center><br>
					
<div class ="row">
      <div class = "col col-lg-">
					<b>Phone Number:</b>
					</div>
					 <div class = "col col-lg-9">
					<input type="text" class = "form-control" name="phone" required><br><br>
					</div></div>
					<div class ="row">
      <div class = "col col-lg-">
					<b>Password </b>
					</div>
					 <div class = "col col-lg-9">
					<input type="password" class = "form-control" name="pass" required><br><br>
					</div>
					</div>
					<button class="btn btn-dark">Submit</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<input type="button" onclick="sign()" value="Sign UP" class="btn btn-primary">
				</form>
			</center>
		</div>
	</div>
    </form>
</body>
</html>

<?php
if (isset($_POST['phone']))
{
    $mob = $_POST['phone'];
    $pass = $_POST['pass'];
    $con = mysqli_connect("localhost", "root", "", "farmers");
    $ss = "SELECT * FROM `farmer` WHERE phone = '$mob'AND pass = '$pass'";
    $ss2 = mysqli_query($con, $ss);

    if($row = mysqli_fetch_array($ss2))
    {
        session_start();
        $_SESSION['x'] = $mob;
        $_SESSION['role']='admin';
        echo"<script>window.location = 'dashf.php'</script>";
    }

    else
    {
        echo"<br>Invalid UserId or Password";
    }
}
?>