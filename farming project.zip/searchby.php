<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script>
        $(document).ready(function()
        {
            $("#b1").click(function()
            {
                var a=$("#s1").val()
                $.post("search.php", {k1:a},function(result)
                {
                    $("#m").html(result);
                });
            });
        })
    </script>
</head>
<body>
   
        <h1>Search Products</h1>
       <select name="searchby" id="s1">
        <option value="crop">Crop</option>
        <option value="fruit">Fruits</option>
        <option value="vegetable">Vegetable</option>
       </select>    
       
        <input type="button" id="b1" value="search">
        <div id="m"></div>
    
</body>
</html>