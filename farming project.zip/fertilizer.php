<!DOCTYPE html> 
<html>
    <head>        
        <title>
                Welcome Farmers !  
                 </title> 
                  <!--
                    <style>
                    body{
                        background-image:url("C:\Users\Vinit Agrawal\Desktop\HackBios\Blurred background");
                    }
                 </style>
                background="Blurred background.jpg",size = 800  px
                -->  
                 <style>

                 </style>    
    </head>
    <Body background="farm2.jpg.">
       <H1>  Fertilizers </H1>    
<!-- <H1> <Font face = 'algerian', align ='Center', size = "10"> Fertilizers </Font>  </H1> 
<font size = 10 > 
-->
<B>
    <ul>
        <li>Fertilizers are the chemical substance that is <br> provided to the crop to increase their production and yielding capacity.
             </li>
        <li>
            Farmers utilize these regularly to boost crop productivity.
        </li>
        <li>
            The fertilizers include - 
        </li>
         <ol type = 1>
            <li> nitrogen </li>
            <li>potassium </li>
            <li> phosphorus </li> 
         </ol>
          which are crucial elements that plants need.
          <li>They also raise the soil's fertility while enhancing <br> its ability to retain water. </li>
    </ul>
</font>

 <h1>  Advantages Of Fertilisers </h1> 
    <!--
        <font size="10"> <center> Advantages Of Fertilisers </center>  </font>
        <font size = 10>--> 
        <ol type =1>
            <li>
             Easy to transport, store, and apply </li>
             <li>
                 For supplying a specific nutrient we can select a specific fertiliser due to its nutrient specific nature
             </li>
             <li>
                 Water-soluble and can easily dissolve in the soil. Hence, they are easily absorbed by the plants.
             </li>
             <li>
                They have a rapid effect on the crops.
             </li>
             <li> 
                 Increase the crop yield and provide enough food to feed the large population.
             </li>
             <li>
                 Predictable and reliable.
             </li>
         </ol>
         <h1> Disadvantages Of Fertilisers </h1>
         <!--<h1> <font color = 'Purple', size="10", align = "Center"> Disadvantages Of Fertilisers </font></h1>-->
    <ol type ="1">
        <li>
            These are Expensive. 
        </li>
        <li>
            The ingredients in the fertilizers are toxic to the skin and respiratory system.
         </li>
         <li>
            Excessive use of fertilisers damages the plants and reduces soil fertility.
         </li>
         <li>
            Leaching occurs and the fertilisers reach the rivers causing eutrophication.
         </li>
         <li>
            Long term use reduces the microbial activity and disturbs the pH of the soil.
         </li>
    </ol>
    <center> <P> To overcome these disadvantages, you should switch to organic Farming. </center> </P>
    </B>







     
</font>
</Body>
</html>