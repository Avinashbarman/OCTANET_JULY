<?php
$name = $_POST['name'];
$mob = $_POST['phone'];
$email = $_POST['email'];
$address = $_POST['address'];
$adhar = $_POST['adhar'];
$pass= $_POST['pass'];

$con = mysqli_connect("localhost", "root", "", "farmers");
$ss = "INSERT INTO `farmer` VALUES('$name','$mob','$email','$address','$adhar','$pass')";
$ss2 = mysqli_query($con, $ss);

if($ss2)
{
    echo"<script>
            alert('SUCCESS'),window.location = 'home.php'
        </script>";
}

else
{
    echo"ERROR";
}
?>