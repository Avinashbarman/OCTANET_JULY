<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Upload Notes</title>
  <script>
    function back()
    {
      window.location = "dashf.php";
    }
  </script>
</head>
<body>
  <form action="addproduct2.php" method="post" enctype="multipart/form-data">

  <h1>Upload Your Product</h1>
  
  Upload Date <input type="datetime-local" name="upldate" required><br><br>
  Full Name <input type="text" name="fullname" placeholder="Full name" require><br><br>
  Phone No <input type="text" name="phone" placeholder="Phone no" require><br><br>
  E Mail <input type="text" name="email" placeholder="E mail id" require><br><br>
  upload Product <input type="file" name="file" required><br><br>
  <select name="type">
    <option value=""></option>
    <option value="crop">Crop</option>
    <option value="fruits">Fruits</option>
    <option value="vegetable">Vegetable</option>
  </select>

        <button>Upload</button>
        
        <button onclick="back()">Back</button>

    </form>
  
</body>
</html>


<?php
session_start();
if(!isset($_SESSION['x']))
{
  echo"<script>window.location = 'home.php'</script>";
}
?>