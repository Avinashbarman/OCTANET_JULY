<?php

$name = $_POST['fname'];
$mob = $_POST['mob'];
$email = $_POST['email'];
$padd = $_POST['padd'];
$comp = $_POST['comp'];
$pan = $_POST['pan'];
$type = $_POST['type'];
$pass = $_POST['pass'];

$con = mysqli_connect("localhost", "root", "", "farmers");
$ss="INSERT INTO `buyer` VALUES('$name','$mob','$email','$padd','$comp','$pan','$type','$pass')";
$ss2 = mysqli_query($con, $ss);

if($ss2)
{
    echo"<script>
            alert('SUCCESS'),window.location = 'home.php'
        </script>";
}

else
{
    echo"ERROR";
}
?>