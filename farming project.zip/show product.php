<?php
session_start();

$m = $_SESSION['x'];

if(!isset($_SESSION['x']))
{
  echo"<script>window.location = 'home.php'</script>";
}

$con=mysqli_connect("localhost","root","","farmers");
$ss="SELECT * FROM product WHERE phone = '$m'";
$ss2=mysqli_query($con,$ss);

echo"
<h1>Uploaded Products</h1>  
<table border='1'>
      <tr><th  style = 'width:200px'>Upload Date</th><th style = 'width:200px'>Full Name</th><th style = 'width:200px'>Email</th><th style = 'width:200px'>Mobile no</th><th style = 'width:200px'>Product</th><th style = 'width:200px'>Update</th></tr>";

      while($row=mysqli_fetch_array($ss2))
      {
        $upldate = $row['upldate'];
        $fullname = $row['fullname'];
        $email = $row['email'];
        $m =$row['phone'];
        $name = $row['name'];
        
        echo"<tr><td align='center'>$upldate</td>
        <td align='center'>$fullname</td>
        <td align='center'>$email</td>
        <td align='center'>$m</td>
        <td align='center'>$name</td>
        <td align='center'><a href='update.php?nid=$row[nid]'>Update Notes</a></td></tr>";
      }

echo "</table>";
?>




   

