<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1 align="center">SCHEMES</h1>
    
    <ol>
        <li><h2>Agriculture Infrastructure Fund</h2>
    <ul><li>A pan India Central Sector Scheme providing debt financing facility for investment in Agri infrastructure</li></ul></li>
    <li><h2>Credit facility for farmers</h2>
    <ul><li>Provides information related to institutional credit available for farmers.</li></ul></li>
     <li><h2>Crop insurance schemes</h2>
    <ul><li>Scheme to safeguard farmers from financial loss occurring due to non-preventable natural risks.</li></ul></li>
    <li><h2>Group Accident Insurance scheme for Fishermen.</h2>
<ul><li>Provides information about Group Accident Insurance scheme for Fishermen provided under Pradhan Mantri Matsya Sampada Yojana</li></ul></li>
<li><h2>Interest subvention for dairy sector</h2>
<ul><li>Interest subvention on Working Capital Loans for Dairy sector due to lockdown</li></ul></li>
<li><h2>KCC for animal husbandry and fisheries</h2>
<ul><li>Provides information about Kisan Credit Card for animal husbandry and fisheries farmers.</li></ul></li>
<li><h2>Krishi UDAN scheme</h2>
<ul><li>The Krishi UDAN 2.0 will be implemented at 53 airports across the country mainly focusing on Northeast and tribal regions and is likely to benefit farmer, freight forwarders and Airlines.</li></ul></li>
   </ol>

</body>
</html>