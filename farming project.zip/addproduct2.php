<?php
session_start();
$m= $_SESSION['x'];
$upldate = $_POST['upldate'];
$fullname = $_POST['fullname'];
$type = $_POST['type'];
$email = $_POST['email'];
$tmp = $_FILES['file']['tmp_name'];
$name = $_FILES['file']['name'];
$date = date('y-m-d h:i:s');

session_start();

    $m = $_SESSION['x'];
if(move_uploaded_file($tmp, $name))
{
    $con=mysqli_connect("localhost","root","","farmers");

    $ss="INSERT INTO `product` VALUES('NULL','$upldate','$fullname','$email','$type','$name','$date','$m')";
    
    $ss2=mysqli_query($con,$ss);
    
    if ($ss2)
    {
        echo" <script>alert('SUCCESS'),window.location='dasht.php'</script>";
    }
    else
    {
        echo"ERROR";
    }
}

?>