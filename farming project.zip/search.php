<?php
$a=$_POST["k1"];
$con=mysqli_connect("localhost","root","","farmers");
$ss="SELECT * FROM `product` WHERE `type` ='$a'";
$ss2=mysqli_query($con,$ss);
echo"<h2>Farmer Details</h2>
<table border='1'>
<tr><th>Name</th><th>Email</th><th>type</th><th>Mobile</th></tr>";
while($row=mysqli_fetch_array($ss2))
{
    $name=$row['fullname'];
    $email=$row['email'];
    $type=$row['type'];
    $phone=$row['phone'];
    
    
    echo"<tr><td>$name</td><td>$email</td><td>$type</td><td>$phone</td></tr>";
}
echo"</table>";;
?>