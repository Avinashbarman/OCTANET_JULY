<?php
session_start();

$mob = $_SESSION['x'];

if(!isset($_SESSION['x']))
{
  echo"<script>window.location = 'home.php'</script>";
}

$con=mysqli_connect("localhost","root","","farmers");
$ss="SELECT * FROM buyer WHERE mob = '$mob'";
$ss2=mysqli_query($con,$ss);

echo"
<h1>Buyer Details</h1>  
<table border='1'>
      <tr><th  style = 'width:200px'>Name</th>
      <th style = 'width:200px'>Email id</th>
      <th style = 'width:200px'>Phone no.</th>
      <th style = 'width:200px'>Parmanent Address</th>
      <th style = 'width:200px'>Company Name</th>
      <th style = 'width:200px'>Type</th></tr>";

      while($row=mysqli_fetch_array($ss2))
      {
        $name=$row['fname'];
        $email=$row['email'];
        $m=$row['mob'];
        $padd=$row['padd'];
        $comp=$row['comp'];
        $type=$row['type'];

        echo"<tr><td align='center'>$name</td>
        <td align='center'>$email</td>
        <td align='center'>$m</td>
        <td align='center'>$padd</td>
        <td align='center'>$comp</td>
        <td align='center'>$type</td></tr>";
      }

echo "</table>";
?>




   

