<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script>
        function sign()
        {
            window.location='buyerregistration.php';
        }

        function forget()
        {
            window.location='forget.php';
        }
    </script>
    	<style>
      .logg{
             border-radius:30px;
	     margin-top:150px;
	     margin-left:350px;
	     margin-right:350px;
	     margin-bottom:200px;
	}
	     
		  
		  body{
            background-image:url("https://i.pinimg.com/originals/b5/58/c1/b558c15b7510220c52c9ed7258683490.jpg");
			background-size:cover;
			
	    
	  }
      
      
   </style>
       <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

</head>
<body>
 <form method="POST">
 <div class = "container" >
		<div class = "logg">
		<center>
 <form method="POST">
    <h1 align="center">Buyer Login</h1><br>
	<div class ="row">
      <div class = "col col-lg-">
    Phone no
	</div>
	 <div class = "col col-lg-9">
	<input type="text" class = "form-control" name="mob" required ><br>
	</div></div>
	<div class ="row">
      <div class = "col col-lg-">
    Password
	</div>
	 <div class = "col col-lg-9">
	<input type="password" class = "form-control" name="pass" required><br>
	</div></div>
	<div class ="row">
      <div class = "col col-lg-">
    <button class="btn btn-dark">Submit</button>
    <input type="button" onclick="sign()" value="sign up" class="btn btn-light">
    <input type="button" onclick="forget()" value="forget password" class="btn btn-danger">
    </form></center>
	</div>
	</div></form>
</body>
</html>
<?php
if(isset($_POST['mob']))
{
    $mob=$_POST['mob'];
    $pass=$_POST['pass'];
    $con=mysqli_connect("localhost","root","","farmers");
    $ss="SELECT * FROM buyer WHERE mob='$mob' AND pass='$pass'";
    $ss2=mysqli_query($con,$ss);

    if($row=mysqli_fetch_array($ss2))
    {
        session_start();
        $_SESSION['x']=$mob;
        $_SESSION['role']='buy';
        echo"<script>window.location='dashb.php'</script>";
    }

    else
    {
        echo"<br>Invalid User id or password";
    }
}
?>